#ifndef EXCEPTION_CPP
#define EXCEPTION_CPP

class IllegalMoveException{};

class NoPossibleMoveSetException{};

class NoSideException{};

class DioMerdosoException{};

#endif